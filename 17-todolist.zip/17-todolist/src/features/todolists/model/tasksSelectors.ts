import { RootState } from "../../../app/store"

export const selectTasks = (state: RootState) => state.tasks
